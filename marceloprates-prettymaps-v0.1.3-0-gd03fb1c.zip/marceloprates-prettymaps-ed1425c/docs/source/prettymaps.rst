User reference
==============

User reference for the prettymaps package.

prettymaps module
--------------------

.. automodule:: prettymaps
    :members:

.. autofunction:: plot